import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import './pages/ProfileUpdateForm'
import './pages/SubmissionHandler'
import SubmissionHandler from './pages/SubmissionHandler'
import ProfileUpdateForm from './pages/ProfileUpdateForm'
import ChangePassword from './pages/ChangePassword'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <SubmissionHandler/> */}
      <ProfileUpdateForm/>
      <ChangePassword></ChangePassword>
    </>
  )
}

export default App
