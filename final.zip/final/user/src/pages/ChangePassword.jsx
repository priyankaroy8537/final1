import React, { useState } from 'react';

const ChangePassword = () => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState(null);
    const [isSuccess, setIsSuccess] = useState(false);
  
    const handleSubmit = async (e) => {
      e.preventDefault();
  
      // Basic validation
      if (!currentPassword || !newPassword || !confirmPassword) {
        setMessage('Please fill in all fields.');
        setIsSuccess(false);
        return;
      }
  
      if (newPassword !== confirmPassword) {
        setMessage('New password and confirmation do not match.');
        setIsSuccess(false);
        return;
      }
  
      // TODO: Implement the API call to change the password in the backend
      // For demonstration purposes, we'll just simulate a successful response
      try {
        // const response = await yourApiService.changePassword(currentPassword, newPassword);
        // if (response.success) {
        //   setMessage('Your password has been successfully changed.');
        //   setIsSuccess(true);
        // } else {
        //   setMessage(response.error || 'An error occurred while changing the password.');
        //   setIsSuccess(false);
        // }
  
        // Simulating a successful password change
        setMessage('Your password has been successfully changed.');
        setIsSuccess(true);
      } catch (error) {
        setMessage('An error occurred while changing the password.');
        setIsSuccess(false);
      }
    };


  return (
    <div className="change-password-container">
    <h2>Change Password</h2>
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="currentPassword">Current Password</label>
        <input
          type="password"
          id="currentPassword"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label htmlFor="newPassword">New Password</label>
        <input
          type="password"
          id="newPassword"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label htmlFor="confirmPassword">Confirm New Password</label>
        <input
          type="password"
          id="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
      </div>
      <button type="submit">Change Password</button>
    </form>
    {message && (
      <div className={`message ${isSuccess ? 'success' : 'error'}`}>
        {message}
      </div>
    )}
  </div>
  )
}
export default ChangePassword;