import React, { useState } from 'react';

export default function ProfileUpdateForm() {
  const [formData, setFormData] = useState({
    telephone: '',
    mobile: '',
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you would normally send the formData to the server
    // For demonstration purposes, we'll just show an alert
    alert('Profile updated successfully!');
    
    // If you're sending the formData to a server, you would handle the response here
    // and show an alert based on the outcome of the profile update request
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="tel"
          name="telephone"
          value={formData.telephone}
          onChange={handleChange}
          placeholder="Telephone"
          required
        />
        <input
          type="tel"
          name="mobile"
          value={formData.mobile}
          onChange={handleChange}
          placeholder="Mobile"
          required
        />
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Email"
          required
        />
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          placeholder="Password"
          required
        />
        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
}
